package com.techprimers.security.securitydbexample.service;

public class UserSecurityService {

}
